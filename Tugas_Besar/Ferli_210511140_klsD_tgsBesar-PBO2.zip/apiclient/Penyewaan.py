import requests
import json
class Penyewaan:
    def __init__(self):
        self.__id=None
        self.__no_polisi = None
        self.__no_pelanggan = None
        self.__nama_penyewa = None
        self.__nama_kendaraan = None
        self.__tgl_sewa = None
        self.__tgl_dikembalikan = None
        self.__biaya_sewa = None
        self.__stts_dikembalikan = None
        self.__url = "http://f0833069.xsph.ru/appsewakendaraan/penyewaan_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def no_polisi(self):
        return self.__no_polisi
        
    @no_polisi.setter
    def no_polisi(self, value):
        self.__no_polisi = value
    @property
    def no_pelanggan(self):
        return self.__no_pelanggan
        
    @no_pelanggan.setter
    def no_pelanggan(self, value):
        self.__no_pelanggan = value
    @property
    def nama_penyewa(self):
        return self.__nama_penyewa
        
    @nama_penyewa.setter
    def nama_penyewa(self, value):
        self.__nama_penyewa = value
    @property
    def nama_kendaraan(self):
        return self.__nama_kendaraan
        
    @nama_kendaraan.setter
    def nama_kendaraan(self, value):
        self.__nama_kendaraan = value
    @property
    def tgl_sewa(self):
        return self.__tgl_sewa
        
    @tgl_sewa.setter
    def tgl_sewa(self, value):
        self.__tgl_sewa = value
    @property
    def tgl_dikembalikan(self):
        return self.__tgl_dikembalikan
        
    @tgl_dikembalikan.setter
    def tgl_dikembalikan(self, value):
        self.__tgl_dikembalikan = value
    @property
    def biaya_sewa(self):
        return self.__biaya_sewa
        
    @biaya_sewa.setter
    def biaya_sewa(self, value):
        self.__biaya_sewa = value
    @property
    def stts_dikembalikan(self):
        return self.__stts_dikembalikan
        
    @stts_dikembalikan.setter
    def stts_dikembalikan(self, value):
        self.__stts_dikembalikan = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_no_pelanggan(self, no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__no_polisi = item['no_polisi']
            self.__no_pelanggan = item['no_pelanggan']
            self.__nama_penyewa = item['nama_penyewa']
            self.__nama_kendaraan = item['nama_kendaraan']
            self.__tgl_sewa = item['tgl_sewa']
            self.__tgl_dikembalikan = item['tgl_dikembalikan']
            self.__biaya_sewa = item['biaya_sewa']
            self.__stts_dikembalikan = item['stts_dikembalikan']
        return data
    def simpan(self):
        payload = {
            "no_polisi":self.__no_polisi,
            "no_pelanggan":self.__no_pelanggan,
            "nama_penyewa":self.__nama_penyewa,
            "nama_kendaraan":self.__nama_kendaraan,
            "tgl_sewa":self.__tgl_sewa,
            "tgl_dikembalikan":self.__tgl_dikembalikan,
            "biaya_sewa":self.__biaya_sewa,
            "stts_dikembalikan":self.__stts_dikembalikan
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_no_pelanggan(self, no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        payload = {
            "no_polisi":self.__no_polisi,
            "no_pelanggan":self.__no_pelanggan,
            "nama_penyewa":self.__nama_penyewa,
            "nama_kendaraan":self.__nama_kendaraan,
            "tgl_sewa":self.__tgl_sewa,
            "tgl_dikembalikan":self.__tgl_dikembalikan,
            "biaya_sewa":self.__biaya_sewa,
            "stts_dikembalikan":self.__stts_dikembalikan
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_no_pelanggan(self,no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
