TUGAS BESAR "APLIKASI SEWA KENDARAAN MOTOR DAN MOBIL"

NAMA    : FERLI
NIM     : 210511140
KELAS   : TI21 D
MATKUL  : PBO2


USER LOGIN SEBAGAI ADMIN
1.  + username = admin
    + password = 123
2.  + username = ferli
    + password = 123

USER LOGIN SEBAGAI PELANGGAN
1.  + username = pelanggan
    + password = 123
2.  + username = elon musk
    + password = 123