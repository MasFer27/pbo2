import requests
import json
class Pelanggan:
    def __init__(self):
        self.__id=None
        self.__no_pelanggan = None
        self.__nama_pelanggan = None
        self.__alamat = None
        self.__no_telepon = None
        self.__url = "http://f0833069.xsph.ru/appsewakendaraan/pelanggan_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def no_pelanggan(self):
        return self.__no_pelanggan
        
    @no_pelanggan.setter
    def no_pelanggan(self, value):
        self.__no_pelanggan = value
    @property
    def nama_pelanggan(self):
        return self.__nama_pelanggan
        
    @nama_pelanggan.setter
    def nama_pelanggan(self, value):
        self.__nama_pelanggan = value
    @property
    def alamat(self):
        return self.__alamat
        
    @alamat.setter
    def alamat(self, value):
        self.__alamat = value
    @property
    def no_telepon(self):
        return self.__no_telepon
        
    @no_telepon.setter
    def no_telepon(self, value):
        self.__no_telepon = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_no_pelanggan(self, no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__no_pelanggan = item['no_pelanggan']
            self.__nama_pelanggan = item['nama_pelanggan']
            self.__alamat = item['alamat']
            self.__no_telepon = item['no_telepon']
        return data
    def simpan(self):
        payload = {
            "no_pelanggan":self.__no_pelanggan,
            "nama_pelanggan":self.__nama_pelanggan,
            "alamat":self.__alamat,
            "no_telepon":self.__no_telepon
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_no_pelanggan(self, no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        payload = {
            "no_pelanggan":self.__no_pelanggan,
            "nama_pelanggan":self.__nama_pelanggan,
            "alamat":self.__alamat,
            "no_telepon":self.__no_telepon
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_no_pelanggan(self,no_pelanggan):
        url = self.__url+"?no_pelanggan="+no_pelanggan
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text