import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from PIL import Image, ImageTk
from Pelanggan import *
class FrmPelanggan:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = False
        self.parent.resizable(False, False)
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent)
        mainFrame.pack(fill=BOTH, expand=YES)

        img1 = Image.open("gambar/bgdboard.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        frame2 = Frame(mainFrame, width=780, height=230, background="#58c2c1")
        frame2.place(x=10, y=10)

        # Label
        Label(frame2, text='APLIKASI FORM PELANGGAN', background="#58c2c1", fg='white', font=('calibri', 24, 'bold')).place(x=20, y=10)
        Label(frame2, text='NO PELANGGAN \t\t:', background="#58c2c1", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=80)
        Label(frame2, text='NAMA PELANGGAN \t:', background="#58c2c1", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=110)
        Label(frame2, text='ALAMAT \t\t\t:', background="#58c2c1", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=140)
        Label(frame2, text='NO TELEPON \t\t:', background="#58c2c1", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=170)

        # Textbox
        self.txtNo_pelanggan = Entry(frame2, font=('calibri', 10, 'bold')) 
        self.txtNo_pelanggan.place(x=220, y=82)
        self.txtNo_pelanggan.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNama_pelanggan = Entry(frame2, font=('calibri', 10, 'bold')) 
        self.txtNama_pelanggan.place(x=220, y=112)
        # Textbox
        self.txtAlamat = Entry(frame2, font=('calibri', 10, 'bold')) 
        self.txtAlamat.place(x=220, y=142)
        # Textbox
        self.txtNo_telepon = Entry(frame2, font=('calibri', 10, 'bold')) 
        self.txtNo_telepon.place(x=220, y=172)
        # Button
        self.btnSimpan = Button(frame2, text='Simpan', command=self.onSimpan, width=10, font=('calibri', 12, 'bold'))
        self.btnSimpan.place(x=470, y=160)
        self.btnClear = Button(frame2, text='Clear', command=self.onClear, width=10, font=('calibri', 12, 'bold'))
        self.btnClear.place(x=570, y=160)
        self.btnHapus = Button(frame2, text='Hapus', command=self.onDelete, width=10, font=('calibri', 12, 'bold'))
        self.btnHapus.place(x=670, y=160)
        # define columns
        columns = ('id','no_pelanggan','nama_pelanggan','alamat','no_telepon')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30")
        self.tree.heading('no_pelanggan', text='NO PELANGGAN')
        self.tree.column('no_pelanggan', width="100")
        self.tree.heading('nama_pelanggan', text='NAMA PELANGGAN')
        self.tree.column('nama_pelanggan', width="190")
        self.tree.heading('alamat', text='ALAMAT')
        self.tree.column('alamat', width="280")
        self.tree.heading('no_telepon', text='NO TELEPON')
        self.tree.column('no_telepon', width="170")
        # set tree position
        self.tree.place(x=10, y=270, width=769, height=320)

        # create a vertical scrollbar
        yscrollbar = ttk.Scrollbar(mainFrame, orient='vertical', command=self.tree.yview)
        yscrollbar.place(x=780, y=270, width=12, height=320)

        # configure the treeview to use the scrollbar
        self.tree.configure(yscrollcommand=yscrollbar.set)
        
    def onClear(self, event=None):
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,"")
        self.txtNama_pelanggan.delete(0,END)
        self.txtNama_pelanggan.insert(END,"")
        self.txtAlamat.delete(0,END)
        self.txtAlamat.insert(END,"")
        self.txtNo_telepon.delete(0,END)
        self.txtNo_telepon.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data pelanggan
        obj = Pelanggan()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["no_pelanggan"],d["nama_pelanggan"],d["alamat"],d["no_telepon"]))
    def onCari(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Pelanggan()
        a = obj.get_by_no_pelanggan(no_pelanggan)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Pelanggan()
        res = obj.get_by_no_pelanggan(no_pelanggan)
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,obj.no_pelanggan)
        self.txtNama_pelanggan.delete(0,END)
        self.txtNama_pelanggan.insert(END,obj.nama_pelanggan)
        self.txtAlamat.delete(0,END)
        self.txtAlamat.insert(END,obj.alamat)
        self.txtNo_telepon.delete(0,END)
        self.txtNo_telepon.insert(END,obj.no_telepon)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        no_pelanggan = self.txtNo_pelanggan.get()
        nama_pelanggan = self.txtNama_pelanggan.get()
        alamat = self.txtAlamat.get()
        no_telepon = self.txtNo_telepon.get()
        # create new Object
        obj = Pelanggan()
        obj.no_pelanggan = no_pelanggan
        obj.nama_pelanggan = nama_pelanggan
        obj.alamat = alamat
        obj.no_telepon = no_telepon
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_no_pelanggan(no_pelanggan)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Pelanggan()
        obj.no_pelanggan = no_pelanggan
        if(self.ditemukan==True):
            res = obj.delete_by_no_pelanggan(no_pelanggan)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPelanggan(root2, "Aplikasi Data Pelanggan")
    root2.mainloop()