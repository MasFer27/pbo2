import requests
import json
class Kendaraan:
    def __init__(self):
        self.__id=None
        self.__no_polisi = None
        self.__jenis_kendaraan = None
        self.__nama_merk = None
        self.__warna = None
        self.__tahun_produksi = None
        self.__biaya_sewa = None
        self.__status_sewa = None
        self.__url = "http://f0833069.xsph.ru/appsewakendaraan/kendaraan_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def no_polisi(self):
        return self.__no_polisi
        
    @no_polisi.setter
    def no_polisi(self, value):
        self.__no_polisi = value
    @property
    def jenis_kendaraan(self):
        return self.__jenis_kendaraan
        
    @jenis_kendaraan.setter
    def jenis_kendaraan(self, value):
        self.__jenis_kendaraan = value
    @property
    def nama_merk(self):
        return self.__nama_merk
        
    @nama_merk.setter
    def nama_merk(self, value):
        self.__nama_merk = value
    @property
    def warna(self):
        return self.__warna
        
    @warna.setter
    def warna(self, value):
        self.__warna = value
    @property
    def tahun_produksi(self):
        return self.__tahun_produksi
        
    @tahun_produksi.setter
    def tahun_produksi(self, value):
        self.__tahun_produksi = value
    @property
    def biaya_sewa(self):
        return self.__biaya_sewa
        
    @biaya_sewa.setter
    def biaya_sewa(self, value):
        self.__biaya_sewa = value
    @property
    def status_sewa(self):
        return self.__status_sewa
        
    @status_sewa.setter
    def status_sewa(self, value):
        self.__status_sewa = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_no_polisi(self, no_polisi):
        url = self.__url+"?no_polisi="+no_polisi
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__no_polisi = item['no_polisi']
            self.__jenis_kendaraan = item['jenis_kendaraan']
            self.__nama_merk = item['nama_merk']
            self.__warna = item['warna']
            self.__tahun_produksi = item['tahun_produksi']
            self.__biaya_sewa = item['biaya_sewa']
            self.__status_sewa = item['status_sewa']
        return data
    def simpan(self):
        payload = {
            "no_polisi":self.__no_polisi,
            "jenis_kendaraan":self.__jenis_kendaraan,
            "nama_merk":self.__nama_merk,
            "warna":self.__warna,
            "tahun_produksi":self.__tahun_produksi,
            "biaya_sewa":self.__biaya_sewa,
            "status_sewa":self.__status_sewa
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_no_polisi(self, no_polisi):
        url = self.__url+"?no_polisi="+no_polisi
        payload = {
            "no_polisi":self.__no_polisi,
            "jenis_kendaraan":self.__jenis_kendaraan,
            "nama_merk":self.__nama_merk,
            "warna":self.__warna,
            "tahun_produksi":self.__tahun_produksi,
            "biaya_sewa":self.__biaya_sewa,
            "status_sewa":self.__status_sewa
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_no_polisi(self,no_polisi):
        url = self.__url+"?no_polisi="+no_polisi
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
