import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from PIL import Image, ImageTk
from Pelanggan import *


class Form1:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = False
        self.parent.resizable(False, False)
        self.aturKomponen()
        
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent)
        mainFrame.pack(fill=BOTH, expand=YES)

        img1 = Image.open("gambar/bgdaftar.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        frame2 = Frame(mainFrame, width=450, height=580, background="#708090")
        frame2.place(x=335, y=10)
        Frame(frame2,width=282, height=2, background="white").place(x=90, y=205)
        Frame(frame2,width=282, height=2, background="white").place(x=90, y=285)
        Frame(frame2,width=282, height=2, background="white").place(x=90, y=365)
        Frame(frame2,width=282, height=2, background="white").place(x=90, y=445)
        Frame(frame2,width=175, height=2, background="#1e5a10").place(x=145, y=73)

        #label

        Label(frame2, text='DAFTAR', fg='#1e5a10', background='#708090', font=("Calibri", 36, "bold")).place(x=150, y=8)
        self.txtNo_pelanggan = Label(frame2, text='NOMOR PELANGGAN', fg='white', background='#708090', font=("Calibri", 20, "bold"))
        self.txtNo_pelanggan.place(x=110, y=130)
        self.txtNama_pelanggan = Label(frame2, text='NAMA PELANGGAN', fg='white', background='#708090', font=("Calibri", 20, "bold"))
        self.txtNama_pelanggan.place(x=115, y=210)
        self.txtAlamat = Label(frame2, text='ALAMAT', fg='white', background='#708090', font=("Calibri", 20, "bold"))
        self.txtAlamat.place(x=180, y=290)
        self.txtNo_telepon = Label(frame2, text='NO TELEPON', fg='white', background='#708090', font=("Calibri", 20, "bold"))
        self.txtNo_telepon.place(x=155, y=370)

        #Entry

        self.txtNo_pelanggan = Entry(frame2,font=("Calibri", 20, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNo_pelanggan.place(x=90, y=170)
        self.txtNama_pelanggan = Entry(frame2,font=("Calibri", 20, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNama_pelanggan.place(x=90, y=250)
        self.txtAlamat = Entry(frame2,font=("Calibri", 20, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtAlamat.place(x=90, y=330)
        self.txtNo_telepon = Entry(frame2,font=("Calibri", 20, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNo_telepon.place(x=90, y=410)

        #Button

        self.btnSimpan = Button(
            frame2,
            text='Simpan',
            font=("Calibri", 22, "bold"),
            fg='#E0FFFF',
            background='#1e5a10',
            width=6,
            height=1,
            border=2,
            activebackground='#708090',
            activeforeground='#1e5a10',
            command=self.onSimpan
        )
        self.btnSimpan.place(x=333, y=515, height=48)

        self.btnSimpan = Button(
            frame2,
            text='🗑',
            font=("Calibri", 22),
            fg="#E0FFFF",
            background='#1e5a10',
            width=2,
            height=1,
            border=2,
            activebackground='#708090',
            activeforeground='#1e5a10',
            command=self.onClear
        )
        self.btnSimpan.place(x=280, y=515, height=48)
    
    def onClear(self, event=None):
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,"")
        self.txtNama_pelanggan.delete(0,END)
        self.txtNama_pelanggan.insert(END,"")
        self.txtAlamat.delete(0,END)
        self.txtAlamat.insert(END,"")
        self.txtNo_telepon.delete(0,END)
        self.txtNo_telepon.insert(END,"")
        self.ditemukan = False
                 
    def onSimpan(self, event=None):
        # get the data from input
        no_pelanggan = self.txtNo_pelanggan.get()
        nama_pelanggan = self.txtNama_pelanggan.get()
        alamat = self.txtAlamat.get()
        no_telepon = self.txtNo_telepon.get()
        # create new Object
        obj = Pelanggan()
        obj.no_pelanggan = no_pelanggan
        obj.nama_pelanggan = nama_pelanggan
        obj.alamat = alamat
        obj.no_telepon = no_telepon
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_no_pelanggan(no_pelanggan)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()

            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()

if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = Form1(root2, "Form Pendaftaran")
    root2.mainloop()

