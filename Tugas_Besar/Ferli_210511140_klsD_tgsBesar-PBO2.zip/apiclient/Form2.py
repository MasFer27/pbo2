import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from tkcalendar import *
from PIL import Image, ImageTk
from Penyewaan import *


class Form2:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = False
        self.parent.resizable(False, False)
        self.aturKomponen()
        
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent)
        mainFrame.pack(fill=BOTH, expand=YES)

        img1 = Image.open("gambar/bgsewa.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        frame2 = Frame(mainFrame, width=450, height=580, background="#708090")
        frame2.place(x=335, y=10)
        Frame(frame2,width=320, height=2, background="#1e5a10").place(x=75, y=60)
        Frame(frame2,width=200, height=2, background="white").place(x=230, y=116)
        Frame(frame2,width=200, height=2, background="white").place(x=230, y=159)
        Frame(frame2,width=200, height=2, background="white").place(x=230, y=202)
        Frame(frame2,width=200, height=2, background="white").place(x=230, y=245)
        Frame(frame2,width=200, height=2, background="white").place(x=230, y=374)

        #label

        Label(frame2, text='SEWA KENDARAAN', fg='#1e5a10', background='#708090', font=("Calibri", 30, "bold")).place(x=70, y=5)
        self.txtNo_pelanggan = Label(frame2, text='NO PELANGGAN\t        :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtNo_pelanggan.place(x=20, y=90)
        self.txtNo_polisi = Label(frame2, text='NO POLISI\t        :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtNo_polisi.place(x=20, y=133)
        self.txtNama_penyewa = Label(frame2, text='NAMA PENYEWA\t        :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtNama_penyewa.place(x=20, y=176)
        self.txtNama_kendaraan = Label(frame2, text='NAMA KENDARAAN       :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtNama_kendaraan.place(x=20, y=219)
        self.txtTgl_sewa = Label(frame2, text='TGL SEWA\t        :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtTgl_sewa.place(x=20, y=262)
        self.txtTgl_dikembalikan = Label(frame2, text='TGL DIKEMBALIKAN       :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtTgl_dikembalikan.place(x=20, y=305)
        self.txtBiaya_sewa = Label(frame2, text='BIAYA SEWA\t        : Rp.', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtBiaya_sewa.place(x=20, y=348)
        self.txtStts_dikembalikan = Label(frame2, text='STATUS DIKEMBALIKAN :', background="#708090", fg='white', font=('calibri', 15, 'bold'))
        self.txtStts_dikembalikan.place(x=20, y=391)

        #Entry

        self.txtNo_pelanggan = Entry(frame2,font=("Calibri", 15, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNo_pelanggan.place(x=230, y=90)
        self.txtNo_polisi = Entry(frame2,font=("Calibri", 15, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNo_polisi.place(x=230, y=133)
        self.txtNama_penyewa = Entry(frame2,font=("Calibri", 15, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNama_penyewa.place(x=230, y=176)
        self.txtNama_kendaraan = Entry(frame2,font=("Calibri", 15, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtNama_kendaraan.place(x=230, y=219)
        self.txtTgl_sewa = DateEntry(frame2, selectmode="day", date_pattern='yyyy-mm-dd', font=('Calibri', 14))
        self.txtTgl_sewa.place(x=230, y=264, width=200, height=25)
        self.txtTgl_dikembalikan = DateEntry(frame2, selectmode="day", date_pattern='yyyy-mm-dd', font=('Calibri', 14))
        self.txtTgl_dikembalikan.place(x=230, y=310, width=200, height=25)
        self.txtBiaya_sewa = Entry(frame2,font=("Calibri", 15, "bold"),border=0,background='#708090',insertbackground='white',fg='white')
        self.txtBiaya_sewa.place(x=262, y=348, width=168)

        self.txtStts_dikembalikan = StringVar()
        Cbo_stts_dikembalikan = ttk.Combobox(frame2, width = 17, textvariable = self.txtStts_dikembalikan, font=('Calibri', 14)) 
        Cbo_stts_dikembalikan.place(x=230, y=395, width=200, height=25)
        # Adding stts_dikembalikan combobox drop down list
        Cbo_stts_dikembalikan['values'] = ('Belum','Sudah')
        Cbo_stts_dikembalikan.current(0)


        #Button

        self.btnSimpan = Button(
            frame2,text='Simpan',
            font=("Calibri", 22, "bold"),
            fg='#E0FFFF',
            background='#1e5a10',
            width=6,
            height=1,
            border=2,
            activebackground='#708090',
            activeforeground='#1e5a10',
            command=self.onSimpan
        )
        self.btnSimpan.place(x=333, y=520, height=45)

        self.btnSimpan = Button(
            frame2,
            text='🗑',
            font=("Calibri", 22),
            fg="#E0FFFF",
            background='#1e5a10',
            width=2,
            height=1,
            border=2,
            activebackground='#708090',
            activeforeground='#1e5a10',
            command=self.onClear
        )
        self.btnSimpan.place(x=280, y=520, height=45)

    def onClear(self, event=None):
        self.txtNo_polisi.delete(0,END)
        self.txtNo_polisi.insert(END,"")
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,"")
        self.txtNama_penyewa.delete(0,END)
        self.txtNama_penyewa.insert(END,"")
        self.txtNama_kendaraan.delete(0,END)
        self.txtNama_kendaraan.insert(END,"")
        self.txtTgl_sewa.delete(0,END)
        self.txtTgl_sewa.insert(END,"")
        self.txtTgl_dikembalikan.delete(0,END)
        self.txtTgl_dikembalikan.insert(END,"")
        self.txtBiaya_sewa.delete(0,END)
        self.txtBiaya_sewa.insert(END,"")
        self.txtStts_dikembalikan.set("")
        self.ditemukan = False

    def onSimpan(self, event=None):
        # get the data from input
        no_polisi = self.txtNo_polisi.get()
        no_pelanggan = self.txtNo_pelanggan.get()
        nama_penyewa = self.txtNama_penyewa.get()
        nama_kendaraan = self.txtNama_kendaraan.get()
        tgl_sewa = self.txtTgl_sewa.get()
        tgl_dikembalikan = self.txtTgl_dikembalikan.get()
        biaya_sewa = self.txtBiaya_sewa.get()
        stts_dikembalikan = self.txtStts_dikembalikan.get()
        # create new Object
        obj = Penyewaan()
        obj.no_polisi = no_polisi
        obj.no_pelanggan = no_pelanggan
        obj.nama_penyewa = nama_penyewa
        obj.nama_kendaraan = nama_kendaraan
        obj.tgl_sewa = tgl_sewa
        obj.tgl_dikembalikan = tgl_dikembalikan
        obj.biaya_sewa = biaya_sewa
        obj.stts_dikembalikan = stts_dikembalikan
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_no_pelanggan(no_pelanggan)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()    

    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()

if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = Form2(root2, "Form Penyewaan")
    root2.mainloop()

