import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from tkcalendar import DateEntry
from PIL import Image, ImageTk
from Penyewaan import *

class FrmPenyewaan:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = False
        self.parent.resizable(False, False)
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent)
        mainFrame.pack(fill=BOTH, expand=YES)

        img1 = Image.open("gambar/bgdboard.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        frame2 = Frame(mainFrame, width=780, height=260, background="#7680ea")
        frame2.place(x=10, y=10)

        Label(frame2, text='APLIKASI', background="#7680ea", fg='white', font=('calibri', 28, 'bold')).place(x=500, y=20)
        Label(frame2, text='FORM PENYEWAAN', background="#7680ea", fg='white', font=('calibri', 28, 'bold')).place(x=420, y=70)
        Label(frame2, text='NO PELANGGAN\t\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=30)
        Label(frame2, text='NO POLISI\t\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=57)
        Label(frame2, text='NAMA PENYEWA\t\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=84)
        Label(frame2, text='NAMA KENDARAAN\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=111)
        Label(frame2, text='TGL SEWA\t\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=138)
        Label(frame2, text='TGL DIKEMBALIKAN\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=165)
        Label(frame2, text='BIAYA SEWA\t\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=192)
        Label(frame2, text='STATUS DIKEMBALIKAN\t:', background="#7680ea", fg='white', font=('calibri', 12, 'bold')).place(x=20, y=219)

        # Textbox
        self.txtNo_pelanggan = Entry(frame2, font=('Calibri', 12)) 
        self.txtNo_pelanggan.place(x=223, y=31, width=126, height=20)
        self.txtNo_pelanggan.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNo_polisi = Entry(frame2, font=('Calibri', 12)) 
        self.txtNo_polisi.place(x=223, y=58, width=126, height=20)
        # Textbox
        self.txtNama_penyewa = Entry(frame2, font=('Calibri', 12)) 
        self.txtNama_penyewa.place(x=223, y=85, width=126, height=20)
        # Textbox
        self.txtNama_kendaraan = Entry(frame2, font=('Calibri', 12)) 
        self.txtNama_kendaraan.place(x=223, y=112, width=126, height=20)
        #Date
        self.txtTgl_sewa = DateEntry(frame2, selectmode="day", date_pattern='yyyy-mm-dd', font=('Calibri', 10, "bold"))
        self.txtTgl_sewa.place(x=223, y=139, width=126, height=20)
        
        self.txtTgl_dikembalikan = DateEntry(frame2, selectmode="day", date_pattern='yyyy-mm-dd', font=('Calibri', 10, "bold"))
        self.txtTgl_dikembalikan.place(x=223, y=166, width=126, height=20)
        # Textbox
        self.txtBiaya_sewa = Entry(frame2, font=('Calibri', 12)) 
        self.txtBiaya_sewa.place(x=223, y=193, width=126, height=20)
        # Combo Box
        self.txtStts_dikembalikan = StringVar()
        Cbo_stts_dikembalikan = ttk.Combobox(frame2, width = 17, textvariable = self.txtStts_dikembalikan, font=('Calibri', 11)) 
        Cbo_stts_dikembalikan.place(x=223, y=223, width=126, height=20)
        # Adding stts_dikembalikan combobox drop down list
        Cbo_stts_dikembalikan['values'] = ('Belum','Sudah')
        Cbo_stts_dikembalikan.current(0)
        # Button
        self.btnSimpan = Button(frame2, text='Simpan', command=self.onSimpan, width=10, font=("calibri", 12, "bold"))
        self.btnSimpan.place(x=430, y=210)
        self.btnClear = Button(frame2, text='Clear', command=self.onClear, width=10, font=("calibri", 12, "bold"))
        self.btnClear.place(x=530, y=210)
        self.btnHapus = Button(frame2, text='Hapus', command=self.onDelete, width=10, font=("calibri", 12, "bold"))
        self.btnHapus.place(x=630, y=210)
        # define columns
        columns = ('id','no_polisi','no_pelanggan','nama_penyewa','nama_kendaraan','tgl_sewa','tgl_dikembalikan','biaya_sewa','stts_dikembalikan')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30", minwidth="30")
        self.tree.heading('no_pelanggan', text='NO PELANGGAN')
        self.tree.column('no_pelanggan', width="100", minwidth="100")
        self.tree.heading('no_polisi', text='NO POLISI')
        self.tree.column('no_polisi', width="100", minwidth="100")
        self.tree.heading('nama_penyewa', text='NAMA PENYEWA')
        self.tree.column('nama_penyewa', width="120", minwidth="120")
        self.tree.heading('nama_kendaraan', text='NAMA KENDARAAN')
        self.tree.column('nama_kendaraan', width="120", minwidth="120")
        self.tree.heading('tgl_sewa', text='TGL SEWA')
        self.tree.column('tgl_sewa', width="100", minwidth="100")
        self.tree.heading('tgl_dikembalikan', text='TGL DIKEMBALIKAN')
        self.tree.column('tgl_dikembalikan', width="130", minwidth="130")
        self.tree.heading('biaya_sewa', text='BIAYA SEWA')
        self.tree.column('biaya_sewa', width="120", minwidth="120")
        self.tree.heading('stts_dikembalikan', text='STATUS DIKEMBALIKAN')
        self.tree.column('stts_dikembalikan', width="150", minwidth="150")
        # set tree position
        self.tree.place(x=7, y=300, width=772, height=279)

        # create a vertical scrollbar
        yscrollbar = ttk.Scrollbar(mainFrame, orient='vertical', command=self.tree.yview)
        yscrollbar.place(x=780, y=300, width=12, height=292)
        # create a horizontal scrollbar
        xscrollbar = ttk.Scrollbar(mainFrame, orient='horizontal', command=self.tree.xview)
        xscrollbar.place(x=7, y=580, width=772, height=12)

        # configure the treeview to use the scrollbar
        self.tree.configure(yscrollcommand=yscrollbar.set, xscrollcommand=xscrollbar.set)
        
    def onClear(self, event=None):
        self.txtNo_polisi.delete(0,END)
        self.txtNo_polisi.insert(END,"")
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,"")
        self.txtNama_penyewa.delete(0,END)
        self.txtNama_penyewa.insert(END,"")
        self.txtNama_kendaraan.delete(0,END)
        self.txtNama_kendaraan.insert(END,"")
        self.txtTgl_sewa.delete(0,END)
        self.txtTgl_sewa.insert(END,"")
        self.txtTgl_dikembalikan.delete(0,END)
        self.txtTgl_dikembalikan.insert(END,"")
        self.txtBiaya_sewa.delete(0,END)
        self.txtBiaya_sewa.insert(END,"")
        self.txtStts_dikembalikan.set("")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data penyewaan
        obj = Penyewaan()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["no_polisi"],d["no_pelanggan"],d["nama_penyewa"],d["nama_kendaraan"],d["tgl_sewa"],d["tgl_dikembalikan"],d["biaya_sewa"],d["stts_dikembalikan"]))
    def onCari(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Penyewaan()
        a = obj.get_by_no_pelanggan(no_pelanggan)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Penyewaan()
        res = obj.get_by_no_pelanggan(no_pelanggan)
        self.txtNo_polisi.delete(0,END)
        self.txtNo_polisi.insert(END,obj.no_polisi)
        self.txtNo_pelanggan.delete(0,END)
        self.txtNo_pelanggan.insert(END,obj.no_pelanggan)
        self.txtNama_penyewa.delete(0,END)
        self.txtNama_penyewa.insert(END,obj.nama_penyewa)
        self.txtNama_kendaraan.delete(0,END)
        self.txtNama_kendaraan.insert(END,obj.nama_kendaraan)
        self.txtTgl_sewa.delete(0,END)
        self.txtTgl_sewa.insert(END,obj.tgl_sewa)
        self.txtTgl_dikembalikan.delete(0,END)
        self.txtTgl_dikembalikan.insert(END,obj.tgl_dikembalikan)
        self.txtBiaya_sewa.delete(0,END)
        self.txtBiaya_sewa.insert(END,obj.biaya_sewa)
        self.txtStts_dikembalikan.set(obj.stts_dikembalikan)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        no_polisi = self.txtNo_polisi.get()
        no_pelanggan = self.txtNo_pelanggan.get()
        nama_penyewa = self.txtNama_penyewa.get()
        nama_kendaraan = self.txtNama_kendaraan.get()
        tgl_sewa = self.txtTgl_sewa.get()
        tgl_dikembalikan = self.txtTgl_dikembalikan.get()
        biaya_sewa = self.txtBiaya_sewa.get()
        stts_dikembalikan = self.txtStts_dikembalikan.get()
        # create new Object
        obj = Penyewaan()
        obj.no_polisi = no_polisi
        obj.no_pelanggan = no_pelanggan
        obj.nama_penyewa = nama_penyewa
        obj.nama_kendaraan = nama_kendaraan
        obj.tgl_sewa = tgl_sewa
        obj.tgl_dikembalikan = tgl_dikembalikan
        obj.biaya_sewa = biaya_sewa
        obj.stts_dikembalikan = stts_dikembalikan
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_no_pelanggan(no_pelanggan)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        no_pelanggan = self.txtNo_pelanggan.get()
        obj = Penyewaan()
        obj.no_pelanggan = no_pelanggan
        if(self.ditemukan==True):
            res = obj.delete_by_no_pelanggan(no_pelanggan)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPenyewaan(root2, "Aplikasi Data Penyewaan")
    root2.mainloop()