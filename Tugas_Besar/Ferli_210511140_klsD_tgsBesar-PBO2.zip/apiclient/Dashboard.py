import tkinter as tk
import json
from tkinter import Frame, Label, Entry, Button, messagebox, Menu
from PIL import Image, ImageTk
from FrmKendaraan import *
from FrmPelanggan import *
from FrmPenyewaan import *
from Form1 import *
from Form2 import *
from Users import *


class Dashboard:
    def __init__(self, parent, title):
        self.parent = parent
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.parent.resizable(False, False)
        self.aturKomponen()

    def new_window(self, number, _class):
        new = tk.Toplevel()
        new.transient()
        new.grab_set()
        _class(new, number)


    def menuAdmin(self):
        self.my_w_child=tk.Toplevel()
        self.my_w_child.geometry('800x600+250+60')
        self.my_w_child.configure(background='#8B0000')
        self.my_w_child.transient(self.parent)
        self.my_w_child.resizable(False, False)
        self.my_w_child.title("MENU ADMIN")

        mainFrame = Frame(
            self.my_w_child,
            background='#708090',
            borderwidth=6,
            relief= 'ridge'
        )
        mainFrame.pack(fill=tk.BOTH, expand=tk.YES)

        img1 = Image.open("gambar/bgadmin.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        kndrnFrame = Frame(
            mainFrame,
            background='#708090',
            borderwidth=6,
            relief='ridge',
            width=770,
            height=85,
        )
        kndrnFrame.place(x=10, y=240)

        plgnFrame = Frame(
            mainFrame,
            background='#708090',
            borderwidth=6,
            relief='ridge',
            width=770,
            height=85,
        )
        plgnFrame.place(x=10, y=355)

        pywnFrame = Frame(
            mainFrame,
            background='#708090',
            borderwidth=6,
            relief='ridge',
            width=770,
            height=85,
        )
        pywnFrame.place(x=10, y=467)

        label = Label(
            kndrnFrame,
            text='DATA KENDARAAN',
            font=('Calibri ', 26, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=35, y=12)

        label = Label(
            plgnFrame,
            text='DATA PELANGGAN',
            font=('Calibri ', 26, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=35, y=12)

        label = Label(
            pywnFrame,
            text='DATA PENYEWAAN',
            font=('Calibri ', 26, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=35, y=12)



        Btn1 = Button(
            mainFrame,
            text='Logout',
            font=("Calibri", 16, 'bold'),
            fg='#E0FFFF',
            background='#708090',
            width=6,
            height=1,
            borderwidth=4,
            command=self.adminDestroy,
        )
        Btn1.place(x=700, y=10)

        Btn1 = Button(
            kndrnFrame,
            text='KLIk DISINI',
            font=("Calibri bold", 18),
            fg='#E0FFFF',
            background='#344',
            width=10,
            height=1,
            borderwidth=4,
            command=lambda: self.new_window("Aplikasi Data kendaraan", FrmKendaraan)
        )
        Btn1.place(x=600, y=8)

        Btn1 = Button(
            plgnFrame,
            text='KLIk DISINI',
            font=("Calibri bold", 18),
            fg='#E0FFFF',
            background='#344',
            width=10,
            height=1,
            borderwidth=4,
            command=lambda: self.new_window("Aplikasi Data kendaraan", FrmPelanggan)
        )
        Btn1.place(x=600, y=8)

        Btn1 = Button(
            pywnFrame,
            text='KLIk DISINI',
            font=("Calibri bold", 18),
            fg='#E0FFFF',
            background='#344',
            width=10,
            height=1,
            borderwidth=4,
            command=lambda: self.new_window("Aplikasi Data kendaraan", FrmPenyewaan)
        )
        Btn1.place(x=600, y=8)
    
    def menuPelanggan(self):
        self.my_w_child2=tk.Toplevel(root)
        self.my_w_child2.geometry('800x600+250+60')
        self.my_w_child2.configure(background='#8B0000')
        self.my_w_child2.transient(self.parent)
        self.my_w_child2.resizable(False, False)
        self.my_w_child2.title("MENU PELANGGAN")

        mainFrame = Frame(
            self.my_w_child2,
            background='#708090',
            borderwidth=6,
            relief= 'ridge'
        )
        mainFrame.pack(fill=tk.BOTH, expand=tk.YES)

        img1 = Image.open("gambar/bgpelanggan.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        Frame2 = Frame(
            mainFrame,
            background='#708090',
            borderwidth=6,
            relief='ridge',
            width=680,
            height=330,
        )
        Frame2.place(x=60, y=220)

        Btn1 = Button(
            mainFrame,
            text='Logout',
            font=("Calibri", 16, 'bold'),
            fg='#E0FFFF',
            background='#708090',
            width=6,
            height=1,
            borderwidth=4,
            command=self.pelangganDestroy
        )
        Btn1.place(x=700, y=10)
        Btn1 = Button(
            Frame2,
            text='DAFTAR',
            font=("Calibri", 16, 'bold'),
            fg='#E0FFFF',
            background='#344',
            width=8,
            height=1,
            borderwidth=4,
            command=lambda: self.new_window("Form Pendaftaran", Form1)
        )
        Btn1.place(x=300, y=80)
        Btn2 = Button(
            Frame2,
            text='SEWA SEKARANG',
            font=("Calibri", 20, 'bold'),
            fg='#E0FFFF',
            background='#344',
            width=18,
            height=1,
            borderwidth=4,
            command=lambda: self.new_window("Form Penyewaan", Form2)
        )
        Btn2.place(x=220, y=230)

        label = Label(
            Frame2,
            text='HARAP MELAKUKAN PENDAFTARAN SEBELUM MENYEWA KENDARAAN',
            font=('Calibri ', 13, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=50, y=42)
        label = Label(
            Frame2,
            text='JIKA SUDAH MENDAFTAR, ANDA BISA MELAKUKAN SEWA KENDARAAN',
            font=('Calibri ', 13, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=50, y=165)
        label = Label(
            Frame2,
            text='DENGAN KLIK TOMBOL DI BAWAH INI',
            font=('Calibri ', 14, 'bold'),
            fg='white',
            background='#708090',
        )
        label.place(x=170, y=185)


    def aturKomponen(self):
        mainFrame = Frame(
            self.parent,
            background='#708090',
            borderwidth=6,
            relief= 'ridge',
        )
        mainFrame.pack(fill=tk.BOTH, expand=tk.YES)
        
        img1 = Image.open("gambar/bgdboard.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)

        mainFrame2 = Frame(
            mainFrame,
            background='#708090',
            borderwidth=6,
            relief='ridge',
            width=300,
            height=300,
        )
        mainFrame2.place(x=240, y=250)


        Frame(mainFrame2, width=147, height=2, bg="white").place(x=70, y=117)
        Frame(mainFrame2, width=147, height=2, bg="white").place(x=70, y=192)

        user = Label(
            mainFrame2,
            text='USER LOGIN',
            font=('calibri bold', 20),
            fg='#E0FFFF',
            background='#708090',
        )
        user.place(x=75, y=5)

        username = Label(
            mainFrame2,
            text='Username',
            font=20,
            fg='#E0FFFF',
            background='#708090',
        )
        username.place(x=108, y=55)

        self.txtUsername = Entry(
            mainFrame2,
            font=('bold', 15),
            border=0,
            background='#708090',
            insertbackground='white',
            fg='white'
        )
        self.txtUsername.place(x=70, y=90, width=150)
        self.txtUsername.focus_set()
        self.txtUsername.bind("<Return>", self.Enter)

        password = Label(
            mainFrame2,
            text="Password",
            font=20,
            fg='#E0FFFF',
            background='#708090',
        )
        password.place(x=108, y=130)

        self.txtPassword = Entry(
            mainFrame2,
            font=('bold', 15),
            border=0,
            background='#708090',
            insertbackground='white',
            fg='white'
        )
        self.txtPassword.place(x=70, y=165, width=150)
        self.txtPassword.config(show='*')
        self.txtPassword.bind("<Return>", self.onLogin)

        Button(
            mainFrame2, 
            text="Created by?", 
            font=("Calibri", 11, "bold"), 
            background="#708090", 
            fg="yellow", 
            border=0, 
            activebackground="#708090",
            activeforeground="red",
            command=self.createdBy
        ).place(x=206, y=260)

        Btn1 = Button(
            mainFrame2,
            text='Login',
            font=("Calibri bold", 20),
            fg='#E0FFFF',
            background='#345',
            width=6,
            height=1,
            border=2,
            command=self.onLogin,
            activebackground='#E0FFFF',
            activeforeground='#345'
        )
        Btn1.place(x=100, y=205)

    
        
    def createdBy(self):
        self.my_w_child3=tk.Toplevel(root)
        self.my_w_child3.geometry('400x300+450+100')
        self.my_w_child3.configure(background='#8B0000')
        self.my_w_child3.resizable(False, False)
        self.my_w_child3.title("Dibuat Oleh")

        mainFrame = Frame(
            self.my_w_child3,
            background='#195e21',
            borderwidth=6,
            relief= 'ridge'
        )
        mainFrame.pack(fill=tk.BOTH, expand=tk.YES)  

        Label(
            mainFrame, 
            text="APLIKASI SEWA KENDARAAN",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 20, "bold")
        ).place(x=30, y=10)

        Frame(mainFrame, width=320, height=2, background="#e0ffff").place(x=33, y=50)

        Label(mainFrame, 
            text="Dibuat Oleh;",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 14, "bold")
        ).place(x=140, y=60)
        Label(mainFrame, 
            text="NAMA : ",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 11, "bold")
        ).place(x=167, y=102)
        Label(mainFrame, 
            text="FERLI",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 24, "bold")
        ).place(x=155, y=119)
        Label(mainFrame, 
            text="NIM : ",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 11, "bold")
        ).place(x=174, y=155)
        Label(mainFrame, 
            text="210511140",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 24, "bold")
        ).place(x=122, y=172)
        Label(mainFrame, 
            text="PRODI : ",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 11, "bold")
        ).place(x=170, y=208)
        Label(mainFrame, 
            text="TEKNIK INFORMATIKA",
            fg='#E0FFFF',
            background='#195e21',
            font=("Calibri", 24, "bold")
        ).place(x=45, y=225)
    


    def onLogin(self, event=None):
        u = self.txtUsername.get()
        p = self.txtPassword.get()
        A = Users()
        B = []
        A.username = u
        A.passwd = p
        res = A.Login()
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]

        if status == 'success':
            if msg == 'admin':
                messagebox.showinfo("Login Success", "Selamattt.. Anda login sebagai Admin")
                self.menuAdmin()
            elif msg == 'pelanggan':
                messagebox.showinfo("Login Success", "Selamattt.. Anda login sebagai Pelanggan")
                self.menuPelanggan()
            else:
                messagebox.showinfo("Login Failed", "Username tidak terdaftar")
        else:
            messagebox.showinfo("Login Failed", "Login gagal, Coba lagi!")

    def Enter(self, event=None):
        self.txtPassword.focus_set()

    def adminDestroy(self, event=None):
        self.my_w_child.destroy()

    def pelangganDestroy(self, event=None):
        self.my_w_child2.destroy()

    def onLogout(self):
        self.aturKomponen()

    def onKeluar(self, event=None):
        self.parent.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    aplikasi = Dashboard(root, "Aplikasi Login")
    root.mainloop()
