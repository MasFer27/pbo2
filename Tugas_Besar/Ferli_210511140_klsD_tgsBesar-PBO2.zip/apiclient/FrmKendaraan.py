import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from PIL import Image, ImageTk
from Kendaraan import *
class FrmKendaraan:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x600+250+60")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = False
        self.parent.resizable(False, False)
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent)
        mainFrame.pack(fill=BOTH, expand=YES)

        img1 = Image.open("gambar/bgdboard.png")
        bgFrame = ImageTk.PhotoImage(img1)
        bglabel = Label(mainFrame, image=bgFrame, border=0, justify='center')
        bglabel.image = bgFrame
        bglabel.pack(fill='both', expand=True)
        bglabel.place(x=0,y=0)


        frame2 = Frame(mainFrame, width=780, height=290, background="#739b6a")
        frame2.place(x=10, y=10)

        Label(frame2, text='APLIKASI', fg='white', background='#739b6a', font=("Calibri", 28, "bold")).place(x=480, y=20)
        Label(frame2, text='FORM KENDARAAN', fg='white', background='#739b6a', font=("Calibri", 28, "bold")).place(x=400, y=70)
        Label(frame2, text='NO POLISI \t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=35)
        Label(frame2, text='JENIS KENDARAAN\t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=69)
        Label(frame2, text='NAMA MERK \t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=103)
        Label(frame2, text='WARNA \t\t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=137)
        Label(frame2, text='TAHUN PRODUKSI \t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=171)
        Label(frame2, text='BIAYA SEWA \t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=205)
        Label(frame2, text='STATUS SEWA \t:', fg='white', background='#739b6a', font=("Calibri", 10, "bold")).place(x=20, y=240)
        Label(frame2, text='/hari', fg='white', background='#739b6a', font=10).place(x=278, y=205)

        # Textbox
        self.txtNo_polisi = Entry(frame2) 
        self.txtNo_polisi.place(x=150, y=35)
        self.txtNo_polisi.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Combo Box
        self.txtJenis_kendaraan = StringVar()
        Cbo_jenis_kendaraan = ttk.Combobox(frame2, width = 17, textvariable = self.txtJenis_kendaraan) 
        Cbo_jenis_kendaraan.place(x=150, y=69)
        # Adding jenis_kendaraan combobox drop down list
        Cbo_jenis_kendaraan['values'] = ('Motor','Mobil')
        Cbo_jenis_kendaraan.current(1)
        # Textbox
        self.txtNama_merk = Entry(frame2) 
        self.txtNama_merk.place(x=150, y=103)
        # Textbox
        self.txtWarna = Entry(frame2) 
        self.txtWarna.place(x=150, y=137)
        # Textbox
        self.txtTahun_produksi = Entry(frame2) 
        self.txtTahun_produksi.place(x=150, y=171)
        # Textbox
        self.txtBiaya_sewa = Entry(frame2) 
        self.txtBiaya_sewa.place(x=150, y=205)
        # Combo Box
        self.txtStatus_sewa = StringVar()
        Cbo_status_sewa = ttk.Combobox(frame2, width = 17, textvariable = self.txtStatus_sewa) 
        Cbo_status_sewa.place(x=150, y=240)
        # Adding status_sewa combobox drop down list
        Cbo_status_sewa['values'] = ('Iya','Tidak')
        Cbo_status_sewa.current(1)
        # Button
        self.btnSimpan = Button(frame2, text='Simpan', command=self.onSimpan, width=10, font=('calibri', 12, 'bold'))
        self.btnSimpan.place(x=400, y=230)
        self.btnClear = Button(frame2, text='Clear', command=self.onClear, width=10, font=('calibri', 12, 'bold'))
        self.btnClear.place(x=510, y=230)
        self.btnHapus = Button(frame2, text='Hapus', command=self.onDelete, width=10, font=('calibri', 12, 'bold'))
        self.btnHapus.place(x=620, y=230)
        # define columns
        columns = ('id','no_polisi','jenis_kendaraan','nama_merk','warna','tahun_produksi','biaya_sewa','status_sewa')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30", minwidth="30")
        self.tree.heading('no_polisi', text='NO POLISI')
        self.tree.column('no_polisi', width="110", minwidth="110")
        self.tree.heading('jenis_kendaraan', text='JENIS KENDARAAN')
        self.tree.column('jenis_kendaraan', width="130", minwidth="130")
        self.tree.heading('nama_merk', text='NAMA MERK')
        self.tree.column('nama_merk', width="120", minwidth="120")
        self.tree.heading('warna', text='WARNA')
        self.tree.column('warna', width="80", minwidth="80")
        self.tree.heading('tahun_produksi', text='TAHUN PRODUKSI')
        self.tree.column('tahun_produksi', width="120", minwidth="120")
        self.tree.heading('biaya_sewa', text='BIAYA SEWA')
        self.tree.column('biaya_sewa', width="130", minwidth="130")
        self.tree.heading('status_sewa', text='STATUS SEWA')
        self.tree.column('status_sewa', width="100", minwidth="100")
        # set tree position
        self.tree.place(x=7, y=320, width=772, height=259)

        # create a vertical scrollbar
        yscrollbar = ttk.Scrollbar(mainFrame, orient='vertical', command=self.tree.yview)
        yscrollbar.place(x=780, y=320, width=12, height=272)
        # create a horizontal scrollbar
        xscrollbar = ttk.Scrollbar(mainFrame, orient='horizontal', command=self.tree.xview)
        xscrollbar.place(x=7, y=580, width=772, height=12)

        # configure the treeview to use the scrollbar
        self.tree.configure(yscrollcommand=yscrollbar.set, xscrollcommand=xscrollbar.set)
        
    def onClear(self, event=None):
        self.txtNo_polisi.delete(0,END)
        self.txtNo_polisi.insert(END,"")
        self.txtJenis_kendaraan.set("")
        self.txtNama_merk.delete(0,END)
        self.txtNama_merk.insert(END,"")
        self.txtWarna.delete(0,END)
        self.txtWarna.insert(END,"")
        self.txtTahun_produksi.delete(0,END)
        self.txtTahun_produksi.insert(END,"")
        self.txtBiaya_sewa.delete(0,END)
        self.txtBiaya_sewa.insert(END,"")
        self.txtStatus_sewa.set("")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data kendaraan
        obj = Kendaraan()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["no_polisi"],d["jenis_kendaraan"],d["nama_merk"],d["warna"],d["tahun_produksi"],d["biaya_sewa"],d["status_sewa"]))
    def onCari(self, event=None):
        no_polisi = self.txtNo_polisi.get()
        obj = Kendaraan()
        a = obj.get_by_no_polisi(no_polisi)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        no_polisi = self.txtNo_polisi.get()
        obj = Kendaraan()
        res = obj.get_by_no_polisi(no_polisi)
        self.txtNo_polisi.delete(0,END)
        self.txtNo_polisi.insert(END,obj.no_polisi)
        self.txtJenis_kendaraan.set(obj.jenis_kendaraan)
        self.txtNama_merk.delete(0,END)
        self.txtNama_merk.insert(END,obj.nama_merk)
        self.txtWarna.delete(0,END)
        self.txtWarna.insert(END,obj.warna)
        self.txtTahun_produksi.delete(0,END)
        self.txtTahun_produksi.insert(END,obj.tahun_produksi)
        self.txtBiaya_sewa.delete(0,END)
        self.txtBiaya_sewa.insert(END,obj.biaya_sewa)
        self.txtStatus_sewa.set(obj.status_sewa)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        no_polisi = self.txtNo_polisi.get()
        jenis_kendaraan = self.txtJenis_kendaraan.get()
        nama_merk = self.txtNama_merk.get()
        warna = self.txtWarna.get()
        tahun_produksi = self.txtTahun_produksi.get()
        biaya_sewa = self.txtBiaya_sewa.get()
        status_sewa = self.txtStatus_sewa.get()
        # create new Object
        obj = Kendaraan()
        obj.no_polisi = no_polisi
        obj.jenis_kendaraan = jenis_kendaraan
        obj.nama_merk = nama_merk
        obj.warna = warna
        obj.tahun_produksi = tahun_produksi
        obj.biaya_sewa = biaya_sewa
        obj.status_sewa = status_sewa
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_no_polisi(no_polisi)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        no_polisi = self.txtNo_polisi.get()
        obj = Kendaraan()
        obj.no_polisi = no_polisi
        if(self.ditemukan==True):
            res = obj.delete_by_no_polisi(no_polisi)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmKendaraan(root2, "Aplikasi Data Kendaraan")
    root2.mainloop()